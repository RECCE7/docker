CREATE TABLE IF NOT EXISTS sessions (session TEXT, table_name TEXT NOT NULL, PRIMARY KEY(session, table_name))
